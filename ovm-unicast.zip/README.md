Installation
============

Step 1: Download the library
---------------------------

Open a command console, enter your project directory and execute the
following command to download the latest stable version of this library:

```console
$ composer require ovm/unicast "~1"
```

This command requires you to have Composer installed globally, as explained
in the [installation chapter](https://getcomposer.org/doc/00-intro.md)
of the Composer documentation.
