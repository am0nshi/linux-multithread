<?php

namespace OVM\Unicast;

class SocketClient
{
    private $connection;
    private $address;
    private $port;

    /**
     * SocketClient constructor.
     *
     * @param resource $connection
     */
    public function __construct($connection)
    {
        $address = '';
        $port    = '';
        socket_getsockname($connection, $address, $port);
        $this->address    = $address;
        $this->port       = $port;
        $this->connection = $connection;
    }

    /**
     * Send message
     *
     * @param string $message
     */
    public function send($message)
    {
        socket_write($this->connection, $message, strlen($message));
    }

    /**
     * Read socket
     *
     * @param integer $len
     *
     * @return string
     */
    public function read($len = 1024)
    {
        if (($buf = @socket_read($this->connection, $len, PHP_BINARY_READ)) === false) {
            return null;
        }

        return $buf;
    }

    /**
     * Get address
     *
     * @return string
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Get port
     *
     * @return integer
     */
    public function getPort()
    {
        return $this->port;
    }

    /*
     * Close socket connection
     */
    public function close()
    {
        socket_shutdown($this->connection);
        socket_close($this->connection);
    }
}
