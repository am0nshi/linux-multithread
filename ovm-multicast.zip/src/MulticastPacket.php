<?php

namespace OVM\Multicast;

class MulticastPacket
{
    protected $delimiter = '|';
    protected $messageSize = 256;

    private $maxPayload;
    private $id;
    private $packets;
    private $currentUuid;
    private $currentType;
    private $currentServiceName;
    private $currentServiceVersion;
    private $currentPacketNumber;
    private $currentPacketTotal;
    private $currentPayload;
    private $chunks;

    /**
     * MulticastPacket constructor.
     */
    public function __construct()
    {
        $this->currentType = '';
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return $this
     */
    public function setType($type)
    {
        $this->currentType = $type;

        return $this;
    }

    /**
     * Set service name
     *
     * @param string $name
     *
     * @return $this
     */
    public function setServiceName($name)
    {
        $this->currentServiceName = $name;

        return $this;
    }

    /**
     * Set service version
     *
     * @param string $version
     *
     * @return $this
     */
    public function setServiceVersion($version)
    {
        $this->currentServiceVersion = $version;

        return $this;
    }

    /**
     * Make chunk
     *
     * @param mixed  $data
     * @param string $id
     *
     * @return $this
     */
    public function chunk($data, $id)
    {
        if (!is_string($data)) {
            $data = json_encode($data);
        }

        $this->id = $id;

        $this->maxPayload = $this->messageSize -strlen(implode($this->delimiter, [
                $this->id,
                $this->currentType,
                $this->currentServiceName,
                $this->currentServiceVersion,
                '000',
                '000',
            ])) - 1 ;


        $this->chunks = ceil(strlen($data) / $this->maxPayload);

        for ($i = 1; $i <= $this->chunks; $i++) {
            $this->packets[] = $this->formatPacketMeta([
                    $this->id,
                    $this->currentType,
                    $this->currentServiceName,
                    $this->currentServiceVersion,
                    str_pad($i, 3, '0', STR_PAD_LEFT),
                    str_pad($this->chunks, 3, '0', STR_PAD_LEFT),
                ]).$this->delimiter.substr($data, ($i - 1) * $this->maxPayload, $this->maxPayload);
        }

        return $this;
    }

    /**
     * Get packets list
     * Return array of objects
     *
     * @return array
     */
    public function getPackets()
    {
        return $this->packets;
    }

    /**
     * Get UUID
     *
     * @return string
     */
    public function getUUID()
    {
        return $this->id;
    }

    /**
     * Format packet headers
     *
     * @param array  $packetHeader
     *
     * @return string
     */
    protected function formatPacketMeta(array $packetHeader)
    {
        $packetMeta = implode($this->delimiter, $packetHeader);

        return $packetMeta;
    }

    /**
     * Mapping incoming data
     *
     * @param string $string
     *
     * @return $this
     */
    public function map($string)
    {
        $packetMeta = explode($this->delimiter, $string, 7);

        $this->currentUuid           = $packetMeta[0];
        $this->currentType           = $packetMeta[1];
        $this->currentServiceName    = $packetMeta[2];
        $this->currentServiceVersion = $packetMeta[3];
        $this->currentPacketNumber   = $packetMeta[4];
        $this->currentPacketTotal    = $packetMeta[5];
        $this->currentPayload        = $packetMeta[6];

        return $this;
    }

    /**
     * Get package number
     *
     * @return int
     */
    public function getPacketNumber()
    {
        return (int) $this->currentPacketNumber;
    }

    /**
     * Get packet total
     *
     * @return int
     */
    public function getPacketTotal()
    {
        return (int) $this->currentPacketTotal;
    }

    /**
     * Get Packet UUID
     *
     * @return string
     */
    public function getPacketUUID()
    {
        return trim($this->currentUuid);
    }

    /**
     * Get packet type
     *
     * @return string
     */
    public function getPacketType()
    {
        return $this->currentType;
    }

    /**
     * Get packet service name
     *
     * @return string
     */
    public function getPacketServiceName()
    {
        return $this->currentServiceName;
    }

    /**
     * Get packet service version
     *
     * @return string
     */
    public function getPacketServiceVersion()
    {
        return $this->currentServiceVersion;
    }

    /**
     * Get packet pay load
     *
     * @return string
     */
    public function getPacketPayload()
    {
        return $this->currentPayload;
    }
}