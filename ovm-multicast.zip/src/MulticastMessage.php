<?php

namespace OVM\Multicast;

class MulticastMessage
{
    private $buff;
    private $uuid;
    private $timeStart;
    private $timeLastSend;
    private $retryCount = 0;
    private $maxRetryCount = 5;
    private $retryTimeout = 0.003;

    const TYPE_REQUEST = 'Q';
    const TYPE_RESPONSE = 'A';
    const TYPE_CONFIRM = 'C';
    const TYPE_EVENT = 'E';
    const TYPE_EVENT_COMPLETE = 'P';
    const TYPE_REQUEST_COMPLETE = 'Y';
    const TYPE_RESPONSE_COMPLETE = 'Z';

    /**
     * MulticastMessage constructor.
     *
     * @param string $data
     * @param string $type
     * @param string $uuid
     * @param string $serviceName
     * @param string $serviceVersion
     */
    function __construct($data, $type = self::TYPE_REQUEST, $uuid, $serviceName = null, $serviceVersion = null)
    {
        $this->uuid      = $uuid ?: uniqid();
        $this->timeStart = microtime(true);
        $this->buff      = (new MulticastPacket())
            ->setType($type)
            ->setServiceName($serviceName)
            ->setServiceVersion($serviceVersion)
            ->chunk($data, $this->uuid)
            ->getPackets();
    }

    /**
     * Check is ready
     *
     * @return bool|null
     */
    public function isReady()
    {
        //TODO:: checks for not spam destination point
        if (microtime(true) < $this->timeLastSend + ($this->retryCount + 1) * $this->retryTimeout) {
            return false;
        } else if ($this->retryCount >= $this->maxRetryCount) {
            return null;
        } else {
            return true;
        }
    }

    /**
     * Send request
     *
     * @param \OVM\Multicast\MulticastServer $server
     *
     * @return bool
     */
    public function send(MulticastServer &$server)
    {
        foreach ($this->buff as $packet) {
            if (!socket_sendto(
                $server->getSocket(),
                $packet,
                strlen($packet),
                0,
                $server->getMulticastIp(),
                $server->getPort()
            )) {
                return false;
            }
        }

        $this->retryCount++;
        $this->timeLastSend = microtime(true);

        return true;
    }

    /**
     * Get uuid
     *
     * @return string
     */
    public function getUUID()
    {
        return trim($this->uuid);
    }
}
