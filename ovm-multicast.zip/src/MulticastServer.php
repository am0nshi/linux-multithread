<?php

namespace OVM\Multicast;

class MulticastServer
{
    const SERVER_MODE_SERVER = 1;
    const SERVER_MODE_CLIENT = 2;
    const SERVER_MODE_EVENT = 3;

    protected $delimiter = '|';

    private $socket;
    private $hwid;
    private $serverMode;
    private $serviceName;
    private $serviceEvents;
    private $serviceVersion;

    private $ip = '127.0.0.1';
    private $multicastIp = '224.5.5.5';
    private $interface = 'eth0';
    private $port = 8888;

    private $sendingBuffer = [];
    private $listeningBuffer = [];
    private $processedBuffer = [];
    private $response;

    /**
     * Array of callable used for server event handling
     *
     * @var callable[]
     */
    private $handlers = [
        'read' => null,
    ];

    /**
     * MulticastServer constructor.
     *
     * @param \OVM\Multicast\MulticastServerConfig $config
     */
    function __construct(MulticastServerConfig $config)
    {
        $this->hwid           = md5(uniqid().microtime(true));
        $this->serviceName    = $config->serviceName;
        $this->serviceVersion = $config->serviceVersion;
        $this->serverMode     = $config->mode;
        $this->serviceEvents  = $config->serviceEvents;
        $this->interface      = $config->iface;
    }

    /**
     * Set interface
     *
     * @param string $interface
     *
     * @return $this
     */
    public function setInterface($interface)
    {
        $this->interface = $interface;

        return $this;
    }

    /**
     * Run server
     */
    public function run()
    {
        $this->socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
        socket_set_option($this->socket, SOL_SOCKET, SO_REUSEPORT, 1);
        socket_set_option($this->socket, SOL_SOCKET, SO_REUSEADDR, 1);
        socket_bind($this->socket, '0.0.0.0', $this->port);
        socket_set_option($this->socket, SOL_SOCKET, SO_BROADCAST, 1);
        socket_set_option(
            $this->socket,
            IPPROTO_IP,
            MCAST_JOIN_GROUP,
            [
                "group"     => $this->multicastIp,
                "interface" => $this->interface,
            ]
        );
    }

    /**
     * Get response
     *
     * @return mixed
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * Start serving
     */
    public function serve()
    {
        $this->listen();
        $this->send();
    }

    /**
     * Send messages
     *
     * @return bool
     */
    public function send()
    {
        /** @var MulticastMessage $message */
        foreach ($this->sendingBuffer as $key => $message) {
            if (!is_null($message->isReady()) && $message->isReady()) {
                $message->send($this);
            } else {
                unset($this->sendingBuffer[$key]);
            }
        }
    }

    /**
     * Listen all traffic and filter it via listening buffer
     */
    public function listen()
    {
        $flags    = \MSG_DONTWAIT;
        $response = '';
        socket_recvfrom($this->socket, $response, 256, $flags, $from, $port);

        if (!empty($response)) {
            switch ($this->serverMode) {
                case self::SERVER_MODE_SERVER :
                    $this->serveAsServer($response);
                    break;
                case self::SERVER_MODE_CLIENT :
                    $this->serveAsClient($response);
                    break;
                case self::SERVER_MODE_EVENT :
                    $this->serveAsEvent($response);
                    break;
            }
        }
    }

    /**
     * Run as server
     *
     * @param string $response
     */
    protected function serveAsServer($response)
    {
        $meta = $this->parseMessage($response);
        if ($meta['type'] == MulticastMessage::TYPE_REQUEST &&
            $meta['name'] == $this->serviceName &&
            $meta['version'] == $this->serviceVersion
        ) {
            $this->listeningBuffer[$meta['uuid']][0] = microtime(true);

            $message = (new MulticastMessage(
                $meta['uuid'],
                MulticastMessage::TYPE_CONFIRM,
                $meta['uuid']
            ));

            $this->addMessage($message);
            $this->addListeningUUID($meta['uuid']);
        }

        if ($meta['type'] == MulticastMessage::TYPE_CONFIRM) {
            return;
        }

        if (array_key_exists($meta['uuid'], $this->listeningBuffer)) {
            if ($meta['type'] == MulticastMessage::TYPE_RESPONSE_COMPLETE) {
                $this->removeListeningUUID($meta['uuid']);
                $this->completeMessage($meta['uuid']);
            }

            $packet = (new MulticastPacket())->map($response);

            if ($packet->getPacketType() == MulticastMessage::TYPE_REQUEST) {
                $this->listeningBuffer[$packet->getPacketUUID()][$packet->getPacketNumber()] = $packet->getPacketPayload();
            }

            if ($message = $this->isMessageComplete(
                $packet->getPacketUUID(),
                $packet->getPacketTotal()
            )
            ) {
                $sendMessage = (new MulticastMessage(
                    $message,
                    MulticastMessage::TYPE_RESPONSE,
                    $meta['uuid']
                ));

                $this->addMessage($sendMessage);
                $this->handle(
                    'read',
                    [
                        'meta'    => $meta,
                        'message' => $message,
                    ]
                );
            }
        }
    }

    /**
     * Run as Event
     *
     * @param string $response
     */
    protected function serveAsEvent($response)
    {
        $meta = $this->parseMessage($response);
        if ($meta['type'] == MulticastMessage::TYPE_EVENT &&
            !array_key_exists($meta['uuid'], $this->processedBuffer) &&
            (in_array($meta['name'], $this->serviceEvents) || $this->serviceEvents == ['*'])
        ) {
            $this->listeningBuffer[$meta['uuid']][0] = microtime(true);
            $message                                 = (new MulticastMessage(
                $meta['uuid'],
                MulticastMessage::TYPE_EVENT_COMPLETE,
                $meta['uuid']
            ));

            $this->addMessage($message);
            $this->addListeningUUID($meta['uuid']);
        }

        if (array_key_exists($meta['uuid'], $this->listeningBuffer)) {
            if ($meta['type'] == MulticastMessage::TYPE_EVENT_COMPLETE) {
                $this->removeListeningUUID($meta['uuid']);
                $this->completeMessage($meta['uuid']);
            }

            $packet = (new MulticastPacket())->map($response);
            $this->listeningBuffer[$packet->getPacketUUID()][$packet->getPacketNumber()]
                    = $packet->getPacketPayload();

            if ($message = $this->isMessageComplete(
                $packet->getPacketUUID(),
                $packet->getPacketTotal()
            )
            ) {

                $this->removeListeningUUID($meta['uuid']);
                $this->completeMessage($meta['uuid']);

                (new MulticastMessage(
                    $meta['uuid'],
                    MulticastMessage::TYPE_REQUEST_COMPLETE,
                    $meta['uuid']
                ))->send(
                    $this
                );

                $this->cleanupProcessedBuffer();

                $message = (new MulticastMessage(
                    'Server processed event',
                    MulticastMessage::TYPE_RESPONSE,
                    $meta['uuid']
                ));

                $this->addMessage($message);
                $this->handle(
                    'read',
                    [
                        'meta'    => $meta,
                        'message' => $message,
                    ]
                );
            }
        }
    }

    /**
     * Run as Client
     *
     * @param string $response
     */
    protected function serveAsClient($response)
    {
        $this->response = null;
        $meta           = $this->parseMessage($response);

        if ($meta['type'] == MulticastMessage::TYPE_REQUEST_COMPLETE
            && array_key_exists($meta['uuid'], $this->listeningBuffer)
        ) {
            $this->completeMessage($meta['uuid']);
        }

        if (array_key_exists($meta['uuid'], $this->listeningBuffer)
            && $meta['type'] == MulticastMessage::TYPE_RESPONSE
        ) {
            $this->completeMessage($meta['uuid']);

            $packet = (new MulticastPacket())->map($response);
            $this->listeningBuffer[$packet->getPacketUUID()][$packet->getPacketNumber()]
                    = $packet->getPacketPayload();

            if ($message = $this->isMessageComplete(
                $packet->getPacketUUID(),
                $packet->getPacketTotal()
            )
            ) {
                (new MulticastMessage(
                    $meta['uuid'],
                    MulticastMessage::TYPE_RESPONSE_COMPLETE,
                    $meta['uuid']
                ))->send(
                    $this
                );

                $this->removeListeningUUID($meta['uuid']);
                $this->response = $message;
                $this->handle(
                    'read',
                    [
                        'meta'    => $meta,
                        'message' => $message,
                    ]
                );
            }
        }
    }

    /**
     * Listen for UUID
     * We wait for response
     *
     * @param string $uuid
     *
     * @return $this
     */
    public function addListeningUUID($uuid)
    {
        $this->listeningBuffer[$uuid][0] = microtime(true);

        return $this;
    }

    /**
     * Remove listener
     *
     * @param string $uuid
     *
     * @return $this
     */
    public function removeListeningUUID($uuid)
    {
        $this->processedBuffer[$uuid] = microtime(true);
        unset($this->listeningBuffer[$uuid]);

        return $this;
    }

    /**
     * Cleanup processed buffer
     *
     * @return $this
     */
    public function cleanupProcessedBuffer()
    {
        foreach ($this->processedBuffer as $k => $v) {
            if ((microtime(true) - $v) > 3) {
                unset($this->processedBuffer[$k]);
            }
        }

        return $this;
    }

    /**
     * Add message
     *
     * @param \OVM\Multicast\MulticastMessage $message
     *
     * @return $this
     */
    public function addMessage(MulticastMessage $message)
    {
        $this->sendingBuffer[$message->getUUID()] = $message;

        return $this;
    }

    /**
     * Complete message
     *
     * @param string $uuid
     *
     * @return $this
     */
    public function completeMessage($uuid)
    {
        unset($this->sendingBuffer[$uuid]);

        return $this;
    }

    /**
     * Get socket
     *
     * @return mixed
     */
    public function getSocket()
    {
        return $this->socket;
    }

    /**
     * Check if message's complete
     *
     * @param string  $uuid
     * @param integer $total
     *
     * @return bool|string
     */
    private function isMessageComplete($uuid, $total)
    {
        if (isset($this->listeningBuffer[$uuid][1]) && (count($this->listeningBuffer[$uuid]) - 1) == $total) {

            unset($this->listeningBuffer[$uuid][0]);
            $message = implode('', $this->listeningBuffer[$uuid]);

            unset($this->listeningBuffer[$uuid]);//TODO:: where to store history to do not process same requests
            return $message;
        } else {
            return false;
        }
    }

    /**
     * Parse message
     *
     * @param string $string
     *
     * @return array
     */
    private function parseMessage($string)
    {
        $packetMeta = explode($this->delimiter, $string);

        return [
            'uuid'    => $packetMeta[0],
            'type'    => $packetMeta[1],
            'name'    => $packetMeta[2],
            'version' => $packetMeta[3],
        ];
    }

    /**
     * Get IP
     *
     * @return string
     */
    public function getIp()
    {
        return $this->ip;
    }

    /**
     * Get multicast id
     *
     * @return string
     */
    public function getMulticastIp()
    {
        return $this->multicastIp;
    }

    /**
     * Get port
     *
     * @return int
     */
    public function getPort()
    {
        return $this->port;
    }

    /**
     * Get state
     *
     * @return bool
     */
    public function getState()
    {
        if ($this->serverMode == self::SERVER_MODE_SERVER ||
            $this->serverMode == self::SERVER_MODE_EVENT ||
            !empty($this->listeningBuffer)
        ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * {@inheritdoc}
     */
    public function onRead($callback)
    {
        self::validateCallableArgument($callback);
        $this->handlers['read'] = $callback;

        return $this;
    }

    /**
     * Invokes the relevant handler and passes the connection as the argument if provided
     *
     * @param string $event one of the handlers
     * @param string $data
     *
     * @return void
     */
    private function handle($event, $data)
    {
        if (!is_null($this->handlers[$event])) {
            $this->handlers[$event]($data);
        }
    }

    /**
     * Validates the number of arguments provided in the callable which should be exactly one.
     *
     * @param callable $callable
     *
     * @throws \DomainException when no arguments provided
     * @throws \DomainException when more than one arguments provided
     *
     * @return void
     */
    private static function validateCallableArgument($callable)
    {
        if (is_array($callable)) {
            $ref = new \ReflectionMethod($callable[0], $callable[1]);
        } else {
            $ref = new \ReflectionFunction($callable);
        }

        $number = $ref->getNumberOfParameters();

        if (!$number) {
            throw new \DomainException('callable must accept connection as an argument');
        }

        if ($number > 1) {
            throw new \DomainException('callable must accept connection as the only argument');
        }
    }
}
