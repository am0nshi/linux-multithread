<?php

namespace OVM\Multicast;

class MulticastServerConfig
{
    public $serviceName;
    public $serviceVersion;
    public $mode;
    public $serviceEvents;
    public $iface;

    /**
     * MulticastServerConfig constructor.
     *
     * @param string $serviceName
     * @param string $serviceVersion
     * @param string $mode
     * @param string $serviceEvents
     * @param string $iface
     */
    function __construct($serviceName, $serviceVersion, $mode, $serviceEvents = null, $iface = 'eth0')
    {
        $this->serviceName    = $serviceName;
        $this->serviceVersion = $serviceVersion;
        $this->mode           = $mode;
        $this->serviceEvents  = $serviceEvents;
        $this->iface          = $iface;
    }
}